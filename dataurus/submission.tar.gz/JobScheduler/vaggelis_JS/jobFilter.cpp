#include "jobFilter.h"

namespace dataurus
{


int jobFilter::Run() {
    
}







}
