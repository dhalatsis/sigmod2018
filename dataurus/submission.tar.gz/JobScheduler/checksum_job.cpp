#include "checksum_job.h"


/*+++++++++++++++++++++++++++++++++++++++*/
/* NON INTERMEDIATE CHECKSUMS FUNCTIONS  */
/*+++++++++++++++++++++++++++++++++++++++*/

int JobCheckSumNonInter::Run () {
        
}
