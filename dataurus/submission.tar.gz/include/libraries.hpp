/* C++ libraries */
#include <stdio.h>
#include <stdlib.h>
#include <cassert>
#include <iostream>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>
#include <assert.h>   // for debugging
#include <pthread.h>            /* pthread_* */
#include <string.h>
#include "sys.h"
#include "tbb_parallel_types.hpp"
#include "tbb/tbb.h"
#include "tbb/parallel_reduce.h"
#include "tbb/parallel_for.h"
#include "tbb/blocked_range.h"
#include "tbb/concurrent_vector.h"
#include "tbb/partitioner.h"
#include <vector>
#include <cstdint>
#include <map>
#include <sys/time.h>
#include <algorithm>
#include <array>
#include <cstdio>
#include <thread>
#include <functional>
#include <limits>
#include <set>
#include <math.h>
#include <unistd.h>
#include <sys/types.h>
#include <asm/unistd.h>
#include <errno.h>
#include <fstream>
