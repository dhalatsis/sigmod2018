rm -rf submission.tar.gz
tar -cf submission.tar.gz CMakeLists.txt compile.sh package.sh run.sh runTestHarnessPublic.sh runTestharness.sh tar.sh cpu_mapping.cpp Filter.cpp generator.cpp harness.cpp Joiner.cpp parallel_radix_join.cpp Parser.cpp Query2SQL.cpp QueryPlan.cpp Relation.cpp Utils.cpp include/ JobScheduler/
